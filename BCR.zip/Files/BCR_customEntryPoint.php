<?php
/*
 *  This file is part of 'BCR Card reader integration'.
 *
 *  'BCR Card reader integration' is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation.
 *
 *  'BCR Card reader integration' is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with 'BCR Card reader integration'.  If not, see http://www.gnu.org/licenses/gpl.html.
 *
 * Copyright March 2014 Olivier Nepomiachty - All rights reserved.
 */
$entry_point_registry['BCR'] = array(
    'file' => 'custom/BCR.php',
    'auth' => false
);
